<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Ordering Menu</title>
</head>
<body>
    <nav class="sidebar">
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Menu</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </nav>
    <main class="content">
        <h1>Welcome to our Menu</h1>
        <div class="menu-items">
            <?php include "menu.php"; ?>
            <?php
            $menuItems = [
                ["name" => "Item 1", "price" => "$10", "image" => "item1.jpg"],
                ["name" => "Item 2", "price" => "$15", "image" => "item2.jpg"],
                ["name" => "Item 3", "price" => "$12", "image" => "item3.jpg"],
                // Add more menu items as needed
            ];

            foreach ($menuItems as $item) {
                echo '<div class="menu-item">';
                echo '<img src="images/' . $item["image"] . '" alt="' . $item["name"] . '">';
                echo '<h2>' . $item["name"] . '</h2>';
                echo '<p>Price: ' . $item["price"] . '</p>';
                echo '</div>';
            }
            ?>
        </div>
        

    </main>
</body>
</html>
